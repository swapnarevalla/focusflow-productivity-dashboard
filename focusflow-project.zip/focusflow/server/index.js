import express from 'express';
import cors from 'cors';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, 'data', 'tasks.json');
let focusSessions = 0;
app.use(cors());
app.use(express.json());

async function readTasks() {
  return JSON.parse(await fs.readFile(DATA_FILE, 'utf8'));
}
async function saveTasks(tasks) {
  await fs.writeFile(DATA_FILE, JSON.stringify(tasks, null, 2));
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok', message: 'FocusFlow API is running' }));
app.get('/api/tasks', async (_req, res) => {
  try { res.json(await readTasks()); } catch { res.status(500).json({ message: 'Could not load tasks' }); }
});
app.post('/api/tasks', async (req, res) => {
  const title = String(req.body.title || '').trim();
  const priority = ['Low', 'Medium', 'High'].includes(req.body.priority) ? req.body.priority : 'Medium';
  if (!title) return res.status(400).json({ message: 'Task title is required' });
  try {
    const tasks = await readTasks();
    const task = { id: Date.now(), title, priority, completed: false };
    tasks.unshift(task);
    await saveTasks(tasks);
    res.status(201).json(task);
  } catch { res.status(500).json({ message: 'Could not save task' }); }
});
app.patch('/api/tasks/:id', async (req, res) => {
  try {
    const tasks = await readTasks();
    const task = tasks.find(item => item.id === Number(req.params.id));
    if (!task) return res.status(404).json({ message: 'Task not found' });
    task.completed = Boolean(req.body.completed);
    await saveTasks(tasks);
    res.json(task);
  } catch { res.status(500).json({ message: 'Could not update task' }); }
});
app.delete('/api/tasks/:id', async (req, res) => {
  try {
    const tasks = await readTasks();
    const remaining = tasks.filter(item => item.id !== Number(req.params.id));
    if (remaining.length === tasks.length) return res.status(404).json({ message: 'Task not found' });
    await saveTasks(remaining);
    res.json({ message: 'Task deleted' });
  } catch { res.status(500).json({ message: 'Could not delete task' }); }
});
app.post('/api/focus-sessions', (_req, res) => {
  focusSessions += 1;
  res.status(201).json({ focusSessions });
});
app.get('/api/summary', async (_req, res) => {
  try {
    const tasks = await readTasks();
    res.json({ total: tasks.length, completed: tasks.filter(t => t.completed).length, pending: tasks.filter(t => !t.completed).length, focusSessions });
  } catch { res.status(500).json({ message: 'Could not load summary' }); }
});
app.listen(PORT, () => console.log(`FocusFlow API running at http://localhost:${PORT}`));
