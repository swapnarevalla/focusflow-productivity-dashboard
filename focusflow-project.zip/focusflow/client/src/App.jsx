import { useEffect, useMemo, useState } from 'react';
import { Activity, CheckCircle2, Circle, Clock3, ListTodo, Plus, Sparkles, Trash2, Play, Pause, RotateCcw, Zap } from 'lucide-react';

const API = 'http://localhost:5000/api';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [summary, setSummary] = useState({ total: 0, completed: 0, pending: 0, focusSessions: 0 });
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [filter, setFilter] = useState('All');
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [message, setMessage] = useState('');

  async function loadData() {
    try {
      const [taskResponse, summaryResponse] = await Promise.all([fetch(`${API}/tasks`), fetch(`${API}/summary`)]);
      if (!taskResponse.ok || !summaryResponse.ok) throw new Error('Could not load data');
      setTasks(await taskResponse.json());
      setSummary(await summaryResponse.json());
      setMessage('');
    } catch {
      setMessage('Cannot connect to the backend. Start the server on port 5000 and refresh.');
    }
  }
  useEffect(() => { loadData(); }, []);
  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => setSeconds(s => {
      if (s <= 1) { clearInterval(timer); setRunning(false); finishFocusSession(); return 0; }
      return s - 1;
    }), 1000);
    return () => clearInterval(timer);
  }, [running]);

  async function finishFocusSession() {
    try { await fetch(`${API}/focus-sessions`, { method: 'POST' }); await loadData(); }
    catch { setMessage('Focus session finished, but the backend did not record it.'); }
  }
  async function addTask(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const response = await fetch(`${API}/tasks`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, priority }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Could not add task');
      setTitle(''); setPriority('Medium'); await loadData();
    } catch { setMessage('Could not add task. Check that the backend is running.'); }
  }
  async function toggleTask(task) {
    try {
      await fetch(`${API}/tasks/${task.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ completed: !task.completed }) });
      await loadData();
    } catch { setMessage('Could not update this task.'); }
  }
  async function deleteTask(id) {
    try { await fetch(`${API}/tasks/${id}`, { method: 'DELETE' }); await loadData(); }
    catch { setMessage('Could not delete this task.'); }
  }
  const visibleTasks = useMemo(() => tasks.filter(t => filter === 'All' || (filter === 'Completed' ? t.completed : !t.completed)), [tasks, filter]);
  const progress = summary.total ? Math.round(summary.completed / summary.total * 100) : 0;
  const clock = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Zap size={21} fill="currentColor" /></div><span>focus<span className="brand-light">flow</span></span></div>
      <div className="workspace-label">WORKSPACE</div>
      <div className="nav-item active"><Activity size={18}/> Overview</div>
      <div className="nav-item"><ListTodo size={18}/> My tasks <span className="nav-count">{summary.pending}</span></div>
      <div className="nav-item"><Clock3 size={18}/> Focus timer</div>
      <div className="sidebar-bottom"><div className="tip-icon"><Sparkles size={18}/></div><p className="tip-title">Small steps add up.</p><p className="tip-copy">Focus on progress, not perfection. One task at a time.</p><div className="tip-progress"><span style={{width: `${progress}%`}} /></div><small>{progress}% of tasks completed</small></div>
      <div className="profile"><div className="avatar">Y</div><div><strong>Your workspace</strong><small>Personal account</small></div><span className="online-dot"/></div>
    </aside>

    <main className="main-content">
      <header className="topbar"><div className="breadcrumb">Workspace <span>/</span> <strong>Overview</strong></div><div className="today-pill"><span className="live-dot"/> Your productivity space</div></header>
      <section className="welcome"><div><p className="eyebrow">YOUR DAILY SPACE</p><h1>Make today <span>count.</span> ✨</h1><p className="welcome-sub">A little focus goes a long way. What would you like to achieve?</p></div><div className="date-card"><div className="date-icon"><Activity size={20}/></div><div><strong>Daily progress</strong><small>Keep your momentum going</small></div></div></section>
      {message && <div className="notice" role="alert">{message}</div>}
      <section className="stats-grid">
        <Stat icon={<ListTodo size={19}/>} label="Total tasks" value={summary.total} detail="In your workspace" className="purple" />
        <Stat icon={<CheckCircle2 size={19}/>} label="Completed" value={summary.completed} detail="Look at you go!" className="green" />
        <Stat icon={<Circle size={19}/>} label="Still to do" value={summary.pending} detail="One step at a time" className="orange" />
        <Stat icon={<Clock3 size={19}/>} label="Focus sessions" value={summary.focusSessions} detail="Sessions completed" className="blue" />
      </section>
      <div className="content-grid">
        <section className="panel task-panel"><div className="panel-heading"><div><div className="heading-icon purple-bg"><ListTodo size={18}/></div><h2>My tasks</h2><p>Turn your plans into progress.</p></div><span className="task-total">{summary.pending} left</span></div>
          <form className="add-form" onSubmit={addTask}><input value={title} onChange={e => setTitle(e.target.value)} placeholder="What needs to get done?" aria-label="New task"/><select value={priority} onChange={e => setPriority(e.target.value)} aria-label="Task priority"><option>Low</option><option>Medium</option><option>High</option></select><button className="add-button" type="submit"><Plus size={18}/><span>Add</span></button></form>
          <div className="filters">{['All', 'Pending', 'Completed'].map(item => <button key={item} onClick={() => setFilter(item)} className={filter === item ? 'filter active-filter' : 'filter'}>{item}</button>)}</div>
          <div className="task-list">{visibleTasks.length ? visibleTasks.map(task => <div className={`task-row ${task.completed ? 'is-complete' : ''}`} key={task.id}><button className="check-button" onClick={() => toggleTask(task)} aria-label={task.completed ? 'Mark as pending' : 'Mark as completed'}>{task.completed ? <CheckCircle2 size={21}/> : <Circle size={21}/>}</button><div className="task-info"><span className="task-name">{task.title}</span><span className={`priority priority-${task.priority.toLowerCase()}`}>{task.priority} priority</span></div><button className="delete-button" onClick={() => deleteTask(task.id)} aria-label="Delete task"><Trash2 size={16}/></button></div>) : <div className="empty-state"><CheckCircle2 size={27}/><strong>All clear!</strong><span>No tasks in this view. Add one to get started.</span></div>}</div>
          <div className="panel-footer"><span><span className="footer-dot"/> Synced with your API</span><span>{summary.completed} of {summary.total} completed</span></div>
        </section>
        <section className="panel focus-panel"><div className="panel-heading"><div><div className="heading-icon blue-bg"><Clock3 size={18}/></div><h2>Focus room</h2><p>Give one thing your full attention.</p></div><span className="pomodoro-label">POMODORO</span></div>
          <div className="timer-wrap"><div className="timer-ring"><div className="timer-inner"><span className="timer-label">TIME TO FOCUS</span><strong>{clock}</strong><span className="timer-sub">25 min session</span></div></div></div>
          <div className="timer-actions"><button className="start-button" onClick={() => { if (seconds === 0) setSeconds(25 * 60); setRunning(v => !v); }}>{running ? <><Pause size={17}/> Pause session</> : <><Play size={17} fill="currentColor"/> {seconds === 0 ? 'Start again' : 'Start focusing'}</>}</button><button className="reset-button" onClick={() => { setRunning(false); setSeconds(25 * 60); }} aria-label="Reset timer"><RotateCcw size={17}/></button></div>
          <div className="focus-note"><Sparkles size={17}/><p><strong>One tip</strong><br/>Silence distractions and focus on just one task until the timer ends.</p></div>
        </section>
      </div>
      <footer className="page-footer">Made for better days <span>·</span> FocusFlow productivity dashboard</footer>
    </main>
  </div>;
}

function Stat({ icon, label, value, detail, className }) {
  return <div className="stat-card"><div className={`stat-icon ${className}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-detail">{detail}</div></div>;
}
